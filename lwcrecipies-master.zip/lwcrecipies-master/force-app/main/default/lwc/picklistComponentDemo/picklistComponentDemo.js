import { LightningElement } from 'lwc';

export default class PicklistComponentDemo extends LightningElement {}