import { LightningElement } from 'lwc';

export default class SlotsDemo extends LightningElement {}