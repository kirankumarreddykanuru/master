import { LightningElement } from 'lwc';

export default class QuickActionService extends LightningElement {}