import { LightningElement, api } from 'lwc';

export default class SlotsWrapper extends LightningElement {
    @api message;
}