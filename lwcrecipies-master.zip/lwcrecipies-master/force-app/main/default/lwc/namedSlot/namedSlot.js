import { LightningElement } from 'lwc';

export default class NamedSlot extends LightningElement {}