import { LightningElement } from 'lwc';

export default class HelloWorld extends LightningElement {
   start ='Welcome !! in the World of ';
   message = 'Lightning Web Component';
}