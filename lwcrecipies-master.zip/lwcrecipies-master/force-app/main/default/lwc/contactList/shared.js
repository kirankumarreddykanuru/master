/* eslint-disable radix */
var add = (n1, n2) =>{
    return parseInt(n1) + parseInt(n2);
}
export{ add }