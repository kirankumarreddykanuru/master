import * as Predicates from "./Predicates";
import * as String from "./String";
import * as StringFilters from "./StringFilters";

export {
    Predicates,
    String,
    StringFilters
}