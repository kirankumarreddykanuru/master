declare module "@salesforce/apex/BoatReviews.saveReview" {
  export default function saveReview(param: {review: any}): Promise<any>;
}
declare module "@salesforce/apex/BoatReviews.getAll" {
  export default function getAll(param: {boatId: any}): Promise<any>;
}
