declare module "@salesforce/apex/BoatSearchFormController.getAllBoatTypes" {
  export default function getAllBoatTypes(): Promise<any>;
}
