declare module "@salesforce/apex/ContactController.getContacts" {
  export default function getContacts(): Promise<any>;
}
