declare module "@salesforce/apex/BoatSearchResults.getBoats" {
  export default function getBoats(param: {boatTypeId: any}): Promise<any>;
}
declare module "@salesforce/apex/BoatSearchResults.getBoatById" {
  export default function getBoatById(param: {boatId: any}): Promise<any>;
}
