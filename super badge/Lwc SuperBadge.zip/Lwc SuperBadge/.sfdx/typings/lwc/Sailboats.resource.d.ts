declare module "@salesforce/resourceUrl/Sailboats" {
    var Sailboats: string;
    export default Sailboats;
}